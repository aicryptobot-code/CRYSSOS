import random

def simulate_raid():
    change = random.uniform(-20, 50)
    return round(change, 2)

def get_token_name():
    names = ["PEPE", "WOJAK", "DOGE", "SHIBA", "FLOKI", "BONK"]
    return random.choice(names)
