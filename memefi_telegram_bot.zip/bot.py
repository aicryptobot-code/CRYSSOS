from telegram import Update
from telegram.ext import Application, CommandHandler, ContextTypes
from config import BOT_TOKEN, ETH_WALLET, USDT_WALLET, SOL_WALLET
from db import init_db, add_user, add_points, get_leaderboard
from logic import simulate_raid, get_token_name

init_db()

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    add_user(user.id, user.username)
    await update.message.reply_text(
        f"🚀 Welcome {user.first_name} to MemeFi Raider!\nType /raid to begin your meme coin journey!"
    )

async def raid(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    token = get_token_name()
    change = simulate_raid()
    points = int(change) if change > 0 else 0
    add_points(user.id, points)
    await update.message.reply_text(
        f"🧨 You raided **{token}**!\n📈 It moved {change}%!\n{'🎉 You earned ' + str(points) + ' points!' if points > 0 else '😢 No gain this time.'}",
        parse_mode="Markdown"
    )

async def leaderboard(update: Update, context: ContextTypes.DEFAULT_TYPE):
    top = get_leaderboard()
    msg = "🏆 Top Raiders:\n\n"
    for i, (user, points) in enumerate(top, 1):
        msg += f"{i}. {user or 'anon'} - {points} pts\n"
    await update.message.reply_text(msg)

async def vip(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "🔓 To unlock VIP access, send payment to one of the following wallets:\n\n"
        f"💰 *ETH / USDT (ERC20)*: `{ETH_WALLET}`\n"
        f"⚡ *Solana (SOL)*: `{SOL_WALLET}`\n\n"
        "Then send the transaction hash to @YourUsername to activate VIP.",
        parse_mode="Markdown"
    )

if __name__ == '__main__':
    app = Application.builder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("raid", raid))
    app.add_handler(CommandHandler("leaderboard", leaderboard))
    app.add_handler(CommandHandler("vip", vip))
    print("🤖 Bot is running...")
    app.run_polling()
