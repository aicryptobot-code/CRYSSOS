import sqlite3

def init_db():
    conn = sqlite3.connect("memefi.db")
    c = conn.cursor()
    c.execute("""CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY,
        username TEXT,
        points INTEGER DEFAULT 0,
        vip INTEGER DEFAULT 0
    )""")
    conn.commit()
    conn.close()

def add_user(user_id, username):
    conn = sqlite3.connect("memefi.db")
    c = conn.cursor()
    c.execute("INSERT OR IGNORE INTO users (id, username) VALUES (?, ?)", (user_id, username))
    conn.commit()
    conn.close()

def add_points(user_id, points):
    conn = sqlite3.connect("memefi.db")
    c = conn.cursor()
    c.execute("UPDATE users SET points = points + ? WHERE id = ?", (points, user_id))
    conn.commit()
    conn.close()

def get_leaderboard():
    conn = sqlite3.connect("memefi.db")
    c = conn.cursor()
    c.execute("SELECT username, points FROM users ORDER BY points DESC LIMIT 10")
    rows = c.fetchall()
    conn.close()
    return rows
